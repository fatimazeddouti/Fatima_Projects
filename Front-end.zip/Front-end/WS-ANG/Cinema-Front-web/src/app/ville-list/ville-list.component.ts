import { Component, OnInit } from '@angular/core';
import {CinemaService} from "../services/cinema.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-ville-list',
  templateUrl: './ville-list.component.html',
  styleUrls: ['./ville-list.component.css']
})
export class VilleListComponent implements OnInit {

  public villes;

  constructor(public cinemaService:CinemaService,private router: Router) { }

  ngOnInit(): void {
    this.cinemaService.getVilles()
      .subscribe(data=>{
        this.villes=data;
      },err=>{
        console.log(err);
      })
  }


  deleteVille(id:number) {
    this.cinemaService.deleteVille(id)
      .subscribe(data=>{
        console.log(data);
      },
        error=>console.log(error));
  }

  VilleDetail(id) {
    this.router.navigate(['details',id]);
  }

  updateVille(id) {

  }
}
