import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CinemaComponent} from "./cinema/cinema.component";
import {VilleListComponent} from "./ville-list/ville-list.component";
import {CreateVilleComponent} from "./create-ville/create-ville.component";


const routes: Routes = [
  {
    path:"cinema",
    component:CinemaComponent
  },
  {
    path:"ville-list",
    component:VilleListComponent
  },
  {
    path:"create-ville",
    component:CreateVilleComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
