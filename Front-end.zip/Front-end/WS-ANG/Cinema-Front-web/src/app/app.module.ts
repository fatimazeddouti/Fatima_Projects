import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from "@angular/common/http";
import { CinemaComponent } from './cinema/cinema.component';
import {FormsModule} from "@angular/forms";
import { CreateVilleComponent } from './create-ville/create-ville.component';
import { VilleDetailsComponent } from './ville-details/ville-details.component';
import { VilleListComponent } from './ville-list/ville-list.component';

@NgModule({
  declarations: [
    AppComponent,
    CinemaComponent,
    CreateVilleComponent,
    VilleDetailsComponent,
    VilleListComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, HttpClientModule, FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
