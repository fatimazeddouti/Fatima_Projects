import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-ville',
  templateUrl: './create-ville.component.html',
  styleUrls: ['./create-ville.component.css']
})
export class CreateVilleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
