import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ville-details',
  templateUrl: './ville-details.component.html',
  styleUrls: ['./ville-details.component.css']
})
export class VilleDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
